package com.mycompany.model;

public enum Gender {
    MALE,
    FEMALE
}
