package com.mycompany.service;

import com.mycompany.dao.AccountDao;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class AccountService {
    private final AccountDao accountDao;

}
