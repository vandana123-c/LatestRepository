package com.mycompany.model;

public enum RoleType {
    USER, ADMIN, OPERATOR, CUSTOMER
}
