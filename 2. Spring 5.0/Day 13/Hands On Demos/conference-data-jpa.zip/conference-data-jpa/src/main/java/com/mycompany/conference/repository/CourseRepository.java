package com.mycompany.conference.repository;

import com.mycompany.conference.model.Course;

public interface CourseRepository {

	Course save(Course course);

}